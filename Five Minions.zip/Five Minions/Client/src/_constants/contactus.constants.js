export const contactUsConstants = {
    CONTACT_US_SUCCESS: 'CONTACTUS_SUCCESS',
    CONTACT_US_FAILURE: 'CONTACTUS_FAILURE',    
};
