export const feedBackConstants = {
    FEEDBACK_SUCCESS: 'FEEDBACK_SUCCESS',
    FEEDBACK_FAILURE: 'FEEDBACK_FAILURE',    
};
