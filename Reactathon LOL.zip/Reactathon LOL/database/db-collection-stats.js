use hacktrixDb

db

db.getCollectionNames()

db.events.stats().count
db.teams.stats().count
db.users.stats().count
db.solutions.stats().count