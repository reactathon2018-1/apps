module.exports = {
    events: require('./events'),
    login: require('./login'),
    teams: require('./teams'),    
    users: require('./users'),    
    solutions: require('./solutions')
};