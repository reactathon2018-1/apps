import React, {Component} from 'react';
import { gql, graphql } from 'react-apollo';
class HackathonDetails extends Component {
  render(){
    console.log(this.props.match.params.id);
      return (<h1>{this.props.match.params.id}</h1>);
  }
}
const AllParams = gql`

query {  
    hackathons {
      eventName,
      summary,
      startDate,
      endDate
    }
  }`;

export default graphql(AllParams)(HackathonDetails);