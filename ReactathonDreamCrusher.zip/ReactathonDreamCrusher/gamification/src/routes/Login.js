import React, {Component} from 'react';

class Login extends Component {
  render(){
   
      return (<h1>Login</h1>);
  }
}

export default Login