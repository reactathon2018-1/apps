import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './js/Login'
import EmployeeView from './js/EmployeeView'
import { Router, Route, Link, IndexRoute } from 'react-router';
import createHistory from 'history/createHashHistory';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Login />
      </div>
    );
  }
}

export default App;
