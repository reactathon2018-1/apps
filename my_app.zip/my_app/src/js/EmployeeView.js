import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar'

class EmployeeView extends Component {
  render() {
    return (
      <div>
      <MuiThemeProvider>
        <div>
        <AppBar
           title="Welcome, employee"
         />
         </div>
         </MuiThemeProvider>
      </div>
    )
  }
};

export default EmployeeView;
