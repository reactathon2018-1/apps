const Jobs = require('./../models/Jobs')
const Login = require('./../models/Login')
const jobDetail = require('./../models/jobDetail')
const fs = require('fs')
const cloudinary = require('cloudinary')

module.exports = {
    addJobs: (req,res,next)=>{
        let {jobId, title, description, location } = req.body
        saveJob({jobId, title, description, location });
        function saveJob(obj) {
            new Jobs(obj).save((err, article) => {
                if (err)
                    res.send(err)
                else if (!article)
                    res.send(400)
                else {
                    // return article.addAuthor(req.body.author_id).then((_article) => {
                        return res.send(article)
                    // )
                }
                next()
            })
        }
    },

    getAllJobs: (req, res, next) => {
        Jobs.find(req.params.jobId).exec((err, article) => {
            if (err)
                res.send(err)
            else if (!article)
                res.send(404)
            else
                res.send(article)
            next()            
        })
    },

    saveCred: (req, res, next)=>{
        let {first_name, last_name, email, password } = req.body
        saveCre({first_name, last_name, email, password });
        function saveCre(obj) {
            new Login(obj).save((err, article) => {
                if (err)
                    res.send(err)
                else if (!article)
                    res.send(400)
                else {
                    // return article.addAuthor(req.body.author_id).then((_article) => {
                        return res.send(article)
                    // })
                }
                next()
            })
        }
    },

    login: (req, res, next)=>{
        console.log("Heya");
        let {email, password} = req.body
        Login.find(req.params.email).exec((err, actual) => {
            console.log(actual);
            if (actual[0].password == password){
                res.send(200)
            }
            else{
                res.send(204)
            }
            next()
        }
    )
       
    }




}