const mongoose = require('mongoose')

let JobsSchema = new mongoose.Schema({
    jobId : String,
    title : String,
    description : String,
    location : String
});

module.exports = mongoose.model('Jobs', JobsSchema)