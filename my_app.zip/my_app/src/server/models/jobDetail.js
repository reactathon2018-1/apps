const mongoose = require('mongoose')

let JobDetailSchema = new mongoose.Schema({
    jobId : String,
    title : String,
    interviewDate : Date,
    skills : [ { 
        technology : String
     } ]
});

JobDetailSchema.methods.addSkill = function(skill){
    this.skills.push(skill);
}

module.exports = mongoose.model('jobDetail', JobDetailSchema)