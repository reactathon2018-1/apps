const mongoose = require('mongoose')

let LoginSchema = new mongoose.Schema({
    first_name : String,
    last_name : String,
    email : String,
    password : String
});

module.exports = mongoose.model('Login', LoginSchema)