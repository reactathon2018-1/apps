const routes = require('./routes')

module.exports = (router) => {
    // user(router)
    routes(router)
}