const articlecontroller = require('./../controllers/ctrl')
const multipart = require('connect-multiparty')
const multipartWare = multipart()
module.exports = (router) => {
    router
        .route('/getJobs')
        .get(articlecontroller.getAllJobs)

    router
    .route('/article')
    .post(multipartWare, articlecontroller.addJobs)

    router
    .route('/saveCred')
    .post(multipartWare, articlecontroller.saveCred)

    router
    .route('/login')
    .post(multipartWare, articlecontroller.login)
}